import { loadCountries, countryAt, normalizeCoordinates } from './geography.js';
import { openDatabase, getDestinations, getAllPhotos, getPhotos, saveDestination, removeDestinations, exportBackup, importBackup, storageMessage } from './db.js';
import { durationLabel, totalDays, validateVisits } from './dates.js';
import { statistics } from './stats.js';
import { createMap } from './map.js';
import { initializeMapFocus } from './map-focus.js';
import { initializePoster } from './poster.js';
import { createGeocoder } from './geocoding.js';
import { groupMediaFiles, processMedia, mediaLabel } from './media.js';
import { createGallery } from './gallery.js';
import { $, escapeHTML, notify, confirmAction, renderList, renderFilterOptions, renderDetail } from './ui.js';
import { initializeSocial } from './social.js';
import { currentUser, signedURL } from './cloud.js';
import { loadCloudMedia, sameCloudMedia, downloadOffline, cancelMediaDownloads } from './cloud-media.js';
import { initializeJourneys } from './journeys.js';
import { initializeRecaps } from './recap.js';
import { initializeWishlist, publicWishlistHTML } from './wishlist.js';
import { shareDestination } from './sharing.js';

let destinations = [], allPhotos = [], selectedId = null, mapController, mapFocus, poster;
let publicView = null, social = null, journeys = null, recaps = null, wishlist = null, changingAccount = false, initializing = true;
const urls = new Map();
let mediaEpoch = 0, previewTimer, offlineToken = 0, offlineActive = 0, previewPaintTimer;
const previewQueue = new Set(), previewPending = new Set(), failedPreviews = new Set();
const previews = new IntersectionObserver(entries => {
  for (const entry of entries) if (entry.isIntersecting) {
    previews.unobserve(entry.target);
    const id = entry.target.dataset.mediaId;
    if (!urls.has(id) && !previewPending.has(id) && !failedPreviews.has(id)) previewQueue.add(id);
  }
  if (previewQueue.size) { clearTimeout(previewTimer); previewTimer = setTimeout(loadPreviews, 80); }
}, { rootMargin: '60px' });
const gallery = createGallery();
let editId, editPhotos = [], coverId, editorToken = 0, photoBusy = false, editorURLs = [], saving = false;
const editor = $('#editor-dialog');
const geocoder = createGeocoder((results) => {
  const container = $('#geocode-results');
  container.replaceChildren();
  for (const result of results) {
    const button = document.createElement('button');
    button.type = 'button'; button.textContent = result.label;
    button.onclick = () => {
      $('#destination-name').value = result.name;
      $('#latitude').value = result.lat; $('#longitude').value = result.lng;
      $('#geocode-input').value = result.label;
      container.replaceChildren(); geocoder.cancel();
      $('#geocode-status').textContent = 'Lugar selecionado. O país é determinado pelas coordenadas.';
      updateCountry(); $('#destination-name').focus();
    };
    container.append(button);
  }
}, (message) => { $('#geocode-status').textContent = message; });

function photosFor(destination) {
  if (!destination) return [];
  const byId = new Map(allPhotos.filter((p) => p.destinationId === destination.id).map((p) => [p.id, p]));
  return destination.photoIds.map((id) => byId.get(id)).filter(Boolean);
}
function observePreviews() {
  previews.disconnect();
  document.querySelectorAll('[data-media-id]').forEach(element => { if (element.dataset.mediaId && !urls.has(element.dataset.mediaId)) previews.observe(element); });
}
function rememberMedia(photo) {
  const index = allPhotos.findIndex(p => sameCloudMedia(p, photo));
  if (index < 0) return;
  allPhotos[index] = { ...allPhotos[index], ...Object.fromEntries(['blob', 'thumbnail', 'motionBlob'].filter(key => photo[key] instanceof Blob).map(key => [key, photo[key]])) };
  if (photo.thumbnail instanceof Blob && !urls.has(photo.id)) urls.set(photo.id, URL.createObjectURL(photo.thumbnail));
  for (const item of editPhotos) if (sameCloudMedia(item, photo)) for (const key of ['thumbnail', 'blob', 'motionBlob']) if (photo[key] instanceof Blob) item[key] = photo[key];
}
async function loadPreviews() {
  const epoch = mediaEpoch, authenticated = !publicView, ids = [...previewQueue]; previewQueue.clear();
  ids.forEach(id => previewPending.add(id));
  let next = 0;
  async function worker() {
    while (next < ids.length && epoch === mediaEpoch) {
      const id = ids[next++], photo = allPhotos.find(p => p.id === id) || editPhotos.find(p => p.id === id);
      try {
        if (!photo?.cloudThumbPath) continue;
        const loaded = await loadCloudMedia(photo, { authenticated, persist: authenticated, valid: () => epoch === mediaEpoch });
        if (epoch !== mediaEpoch) return;
        rememberMedia(loaded);
        clearTimeout(previewPaintTimer); previewPaintTimer = setTimeout(() => {
          if (epoch !== mediaEpoch) return;
          updateList(); renderSelected(); mapController.refreshPhotos(urls);
          document.querySelectorAll('#photo-editor [data-media-id]').forEach(element => {
            const url = urls.get(element.dataset.mediaId);
            if (url) { const img = document.createElement('img'); img.src = url; img.alt = 'Prévia da mídia'; element.replaceChildren(img); }
          });
        }, 80);
      } catch (error) { if (epoch === mediaEpoch && error.name !== 'AbortError') failedPreviews.add(id); }
      finally { if (epoch === mediaEpoch) previewPending.delete(id); }
    }
  }
  await Promise.all([worker(), worker()]);
}
function resetMediaView() {
  mediaEpoch++; offlineToken++; previews.disconnect(); previewQueue.clear(); previewPending.clear(); failedPreviews.clear(); clearTimeout(previewTimer); clearTimeout(previewPaintTimer);
  cancelMediaDownloads(); offlineActive = 0; $('#download-media-button').disabled = changingAccount || initializing; $('#cancel-media-download').hidden = true;
}
function openGallery(photos, index) {
  const epoch = mediaEpoch, authenticated = !publicView;
  gallery.open(photos, index, { load: async (photo, { motion = false } = {}) => {
    const latest = allPhotos.find(p => sameCloudMedia(p, photo)) || photo;
    const valid = () => epoch === mediaEpoch;
    if (!valid()) throw new DOMException('Operação cancelada.', 'AbortError');
    if (latest.kind === 'video' && !(latest.blob instanceof Blob)) return { ...latest, url: await signedURL('atlas-media', latest.cloudPath, authenticated) };
    if (motion && !(latest.motionBlob instanceof Blob)) return { ...latest, motionURL: await signedURL('atlas-media', latest.cloudMotionPath, authenticated) };
    const loaded = await loadCloudMedia(latest, { parts: ['blob'], authenticated, persist: authenticated, valid });
    if (valid()) rememberMedia(loaded);
    return loaded;
  } });
}
function renderSelected() {
  const destination = destinations.find((d) => d.id === selectedId);
  if (!destination) { selectedId = null; $('#list-panel').hidden = false; $('#detail-panel').hidden = true; return; }
  const photos = photosFor(destination);
  renderDetail(destination, photos, urls, {
    readOnly: Boolean(publicView), account: Boolean(currentUser()),
    back: () => { selectedId = null; renderSelected(); },
    edit: () => openEditor(destination),
    remove: async () => {
      if (!await confirmAction(`Excluir ${destination.name}?`, 'O destino, suas visitas e todas as fotos serão removidos deste navegador. Exporte um backup se quiser guardar uma cópia.')) return;
      try { await removeDestinations([destination.id]); selectedId = null; await refresh(); social?.afterMutation(); notify('Destino excluído.'); }
      catch (error) { notify(storageMessage(error), true); }
    },
    gallery: (index) => openGallery(photos, index),
    share: () => shareDestination(destination, publicView?.profile),
  });
  observePreviews();
}
function selectDestination(id) {
  const destination = destinations.find((d) => d.id === id);
  if (!destination) return;
  selectedId = id; renderSelected(); mapController.flyTo(destination);
  if (matchMedia('(max-width: 700px)').matches) $('#destinations-panel').scrollIntoView({ behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' });
  $('#destinations-panel').scrollTop = 0;
}
function updateList() { renderList(destinations, urls, selectDestination, () => openEditor(), Boolean(publicView)); observePreviews(); }
function clearFilters() {
  $('#list-search').value = ''; $('#country-filter').value = ''; $('#tag-filter').value = '';
  document.querySelectorAll('[data-collection-filter]').forEach((button) => button.setAttribute('aria-pressed', String(button.dataset.collectionFilter === 'all')));
}
function announceAppState() {
  const detail = { ready: !initializing && !changingAccount, publicView: Boolean(publicView), signedIn: Boolean(currentUser()), personalCount: destinations.filter(d => !d.example).length };
  document.documentElement.dataset.atlasState = JSON.stringify(detail);
  document.dispatchEvent(new CustomEvent('atlas:state', { detail }));
}
function setAccountLoading(value) {
  changingAccount = value;
  if (value && offlineActive) { offlineToken++; offlineActive = 0; cancelMediaDownloads(); $('#cancel-media-download').hidden = true; $('#offline-media-status').textContent = 'Download interrompido. As mídias já baixadas foram preservadas.'; }
  for (const selector of ['#add-button', '#export-button', '#import-button', '#wishlist-button', '#clean-map-button', '#download-media-button', '#poster-button']) $(selector).disabled = value || initializing;
  announceAppState();
}
async function refresh() {
  destinations = publicView ? publicView.destinations : await getDestinations();
  destinations = destinations.map(d => ({ ...d, ...countryAt(d.lat,d.lng) }));
  allPhotos = publicView ? publicView.photos : await getAllPhotos();
  for (const url of urls.values()) URL.revokeObjectURL(url);
  urls.clear();
  for (const photo of allPhotos) if (photo.thumbnail instanceof Blob) urls.set(photo.id, URL.createObjectURL(photo.thumbnail));
  failedPreviews.clear();
  renderFilterOptions(destinations); updateList(); renderSelected();
  if (publicView) $('#examples-banner').hidden = true;
  const stats = statistics(destinations);
  for (const [key, value] of Object.entries(stats)) $(`#stat-${key}`).textContent = new Intl.NumberFormat('pt-BR').format(value);
  mapController.update(destinations, urls);
  await wishlist?.refresh();
  announceAppState();
}
function updateCountry() {
  try {
    const { lat, lng } = normalizeCoordinates($('#latitude').value, $('#longitude').value);
    const info = countryAt(lat, lng);
    $('#country-preview').textContent = info.countryId ? `${info.countryName} · ${info.continent} — ${info.countryApproximate ? 'aproximado pela proximidade da costa (até 3 km). Confira as coordenadas.' : 'identificado pelas coordenadas'}` : 'País não identificado. Pode ser uma ilha pequena, uma área costeira ou um ponto no oceano. O destino pode ser salvo.';
  } catch { $('#country-preview').textContent = 'Informe coordenadas válidas para identificar o país.'; }
}
function readVisits() {
  return [...$('#visits-editor').querySelectorAll('.visit-editor')].map((row) => {
    const manual = $('[data-manual]', row).checked;
    return {
      id: row.dataset.visitId, arrival: manual ? '' : $('[data-arrival]', row).value, departure: manual ? '' : $('[data-departure]', row).value,
      manualDays: manual ? ($('[data-days]', row).value === '' ? '' : Number($('[data-days]', row).value)) : null,
    };
  });
}
function updateDuration() {
  const visits = readVisits();
  try { validateVisits(visits); $('#duration-preview').textContent = durationLabel(totalDays({ visits })); }
  catch (error) { $('#duration-preview').textContent = error.message; }
}
function addVisit(visit = {}) {
  const id = visit.id || crypto.randomUUID(), manual = visit.manualDays != null;
  const row = document.createElement('div');
  row.className = 'visit-editor'; row.dataset.visitId = id;
  const unique = crypto.randomUUID();
  row.innerHTML = `<div class="visit-heading"><span>Visita</span><button type="button" data-remove-visit aria-label="Remover visita">Remover</button></div><div class="visit-dates" ${manual ? 'hidden' : ''}><label for="arrival-${unique}">Chegada<input id="arrival-${unique}" type="date" data-arrival value="${escapeHTML(visit.arrival || '')}" ${manual ? 'disabled' : ''}></label><label for="departure-${unique}">Partida<input id="departure-${unique}" type="date" data-departure value="${escapeHTML(visit.departure || '')}" ${manual ? 'disabled' : ''}></label></div><label class="manual-toggle"><input type="checkbox" data-manual ${manual ? 'checked' : ''}> Não lembro as datas</label><label class="manual-duration" ${manual ? '' : 'hidden'}>Duração em dias<input type="number" min="1" max="365000" step="1" data-days value="${escapeHTML(visit.manualDays ?? '')}" ${manual ? 'required' : 'disabled'}></label>`;
  $('[data-manual]', row).onchange = () => {
    const checked = $('[data-manual]', row).checked;
    $('.visit-dates', row).hidden = checked; $('.manual-duration', row).hidden = !checked;
    $('[data-arrival]', row).disabled = checked; $('[data-departure]', row).disabled = checked;
    $('[data-days]', row).disabled = !checked; $('[data-days]', row).required = checked;
    updateDuration();
  };
  $('[data-remove-visit]', row).onclick = () => { row.remove(); updateDuration(); };
  row.addEventListener('input', updateDuration);
  $('#visits-editor').append(row); updateDuration();
}
function releaseEditorURLs() { editorURLs.forEach((url) => URL.revokeObjectURL(url)); editorURLs = []; }
function renderPhotoEditor() {
  releaseEditorURLs();
  const container = $('#photo-editor');
  container.replaceChildren();
  editPhotos.forEach((photo, index) => {
    const url = photo.thumbnail instanceof Blob ? URL.createObjectURL(photo.thumbnail) : null; if (url) editorURLs.push(url);
    const card = document.createElement('div'); card.className = 'photo-edit-card';
    card.innerHTML = `<div class="photo-edit-preview" data-media-id="${escapeHTML(photo.id)}">${url ? `<img src="${url}" alt="Prévia da foto ${index + 1}">` : '<span class="media-placeholder" aria-hidden="true">◇</span>'}</div><span class="media-badge">${mediaLabel(photo)}</span><label>Legenda da foto ${index + 1}<input type="text" maxlength="1000" data-caption value="${escapeHTML(photo.caption)}"></label><div class="photo-controls"><label><input type="radio" name="cover" data-cover ${coverId === photo.id ? 'checked' : ''}> Capa</label><button type="button" data-remove-photo aria-label="Remover foto ${index + 1}">Remover</button></div>`;
    $('[data-caption]', card).oninput = (e) => { photo.caption = e.target.value; };
    $('[data-cover]', card).onchange = () => { coverId = photo.id; };
    $('[data-remove-photo]', card).onclick = () => {
      editPhotos = editPhotos.filter((p) => p.id !== photo.id);
      if (coverId === photo.id) coverId = editPhotos[0]?.id || null;
      renderPhotoEditor();
    };
    container.append(card);
  });
  observePreviews();
}
async function openEditor(destination, coords = {}) {
  if (changingAccount) return notify('Aguarde a atualização da sua coleção.');
  if (publicView) return notify('Volte ao Meu atlas para adicionar ou editar suas viagens.');
  const token = ++editorToken;
  editId = destination?.id || crypto.randomUUID(); coverId = destination?.coverId || null;
  editPhotos = []; photoBusy = false; saving = false;
  $('#destination-form').reset(); $('#form-error').hidden = true;
  $('#editor-title').textContent = destination ? 'Editar destino' : 'Adicionar destino';
  $('#save-button').disabled = false; $('#save-button').textContent = 'Salvar destino';
  $('#destination-name').value = destination?.name || '';
  $('#destination-kind').value = destination?.kind || 'trip';
  $('#latitude').value = destination?.lat ?? coords.lat ?? '';
  $('#longitude').value = destination?.lng ?? coords.lng ?? '';
  $('#notes').value = destination?.notes || ''; $('#rating').value = destination?.rating || '0'; $('#tags').value = destination?.tags.join(', ') || '';
  $('#visibility-field').hidden = $('#visibility-hint').hidden = !currentUser();
  $('#visibility').value = destination?.visibility || 'private';
  $('#destination-favorite').checked = destination?.favorite === true;
  $('#destination-pinned').checked = destination?.pinned === true;
  $('#geocode-results').replaceChildren(); $('#geocode-status').textContent = 'Digite ao menos 3 caracteres ou use as coordenadas abaixo.';
  $('#photo-status').textContent = 'Fotos: até 40 MB; vídeos: até 50 MB, sem compressão. Live Photo: foto + vídeo com o mesmo nome, selecionados juntos. No iPhone, use Fotos → ••• → Salvar como Vídeo se vier só a foto.';
  $('#visits-editor').replaceChildren();
  for (const visit of destination?.visits.length ? destination.visits : [{}]) addVisit(visit);
  updateCountry(); renderPhotoEditor(); editor.showModal();
  if (coords.lat != null) $('#destination-name').focus(); else $('#geocode-input').focus();
  if (destination) {
    photoBusy = true; $('#save-button').disabled = true;
    try { const loaded = await getPhotos(destination.id); if (token !== editorToken) return; editPhotos = loaded; renderPhotoEditor(); }
    catch (error) { editor.close(); notify(storageMessage(error), true); }
    finally { if (token === editorToken) { photoBusy = false; $('#save-button').disabled = false; } }
  }
}
async function addPhotos(files) {
  if (photoBusy || !files.length) return;
  const groups = groupMediaFiles(files);
  if (groups.length + editPhotos.length > 100) { notify('Use até 100 fotos, vídeos ou Live Photos por destino.', true); return; }
  const token = editorToken; photoBusy = true; $('#save-button').disabled = true;
  const errors = [];
  try {
    for (let i = 0; i < groups.length; i++) {
      $('#photo-status').textContent = `Preparando mídia ${i + 1} de ${groups.length}…`;
      try {
        const photo = await processMedia(groups[i], editId);
        if (token !== editorToken) return;
        editPhotos.push(photo); coverId ||= photo.id;
      } catch (error) { errors.push(error.message); }
    }
    if (token !== editorToken) return;
    renderPhotoEditor();
    $('#photo-status').textContent = errors.length ? errors.join(' ') : `${editPhotos.length} ${editPhotos.length === 1 ? 'mídia pronta' : 'mídias prontas'} para salvar.`;
    if (errors.length) notify(errors.join(' '), true);
  } finally { if (token === editorToken) { photoBusy = false; $('#save-button').disabled = false; } }
}
async function save(event) {
  event.preventDefault();
  if (photoBusy || saving || changingAccount || publicView) return;
  $('#form-error').hidden = true;
  try {
    const coords = normalizeCoordinates($('#latitude').value, $('#longitude').value);
    const name = $('#destination-name').value.trim();
    if (!name) throw new Error('Informe o nome do destino.');
    const visits = readVisits(); validateVisits(visits);
    const previous = destinations.find((d) => d.id === editId);
    const tags = [...new Set($('#tags').value.split(',').map((tag) => tag.trim()).filter(Boolean))];
    if (tags.length > 30 || tags.some((t) => t.length > 40)) throw new Error('Use até 30 etiquetas com até 40 caracteres cada.');
    const now = new Date().toISOString();
    const destination = { id: editId, name, ...coords, ...countryAt(coords.lat, coords.lng), visits,
      notes: $('#notes').value.trim(), rating: Number($('#rating').value), tags,
      photoIds: editPhotos.map((p) => p.id), coverId: editPhotos.some((p) => p.id === coverId) ? coverId : editPhotos[0]?.id || null,
      kind: $('#destination-kind').value, favorite: $('#destination-favorite').checked, pinned: $('#destination-pinned').checked,
      example: false, createdAt: previous?.createdAt || now, updatedAt: now };
    if (currentUser()) { destination.visibility = $('#visibility').value; destination.cloudRevision = previous?.cloudRevision || null; }
    saving = true; $('#save-button').disabled = true; $('#save-button').textContent = 'Salvando…';
    await saveDestination(destination, editPhotos);
    editor.close(); selectedId = destination.id; await refresh(); mapController.flyTo(destination);
    social?.afterMutation();
    notify(currentUser() ? 'Viagem salva neste dispositivo. A sincronização com sua conta foi agendada.' : 'Destino salvo. Mais um lugar na sua história.');
  } catch (error) {
    $('#form-error').textContent = storageMessage(error); $('#form-error').hidden = false;
    $('#form-error').scrollIntoView({ block: 'nearest' });
  } finally { saving = false; $('#save-button').disabled = false; $('#save-button').textContent = 'Salvar destino'; }
}
function bindEvents() {
  $('#add-button').onclick = () => openEditor();
  $('#editor-close').onclick = $('#editor-cancel').onclick = () => { if (!saving) editor.close(); };
  editor.addEventListener('cancel', (e) => { if (saving) e.preventDefault(); });
  editor.addEventListener('close', () => { editorToken++; geocoder.cancel(); releaseEditorURLs(); });
  $('#geocode-input').oninput = (e) => geocoder.search(e.target.value);
  $('#latitude').oninput = $('#longitude').oninput = updateCountry;
  $('#add-visit').onclick = () => addVisit();
  $('#destination-form').onsubmit = save;
  $('#photo-input').onchange = async (e) => { await addPhotos([...e.target.files]); e.target.value = ''; };
  const zone = $('#drop-zone');
  for (const type of ['dragenter', 'dragover']) zone.addEventListener(type, (e) => { e.preventDefault(); zone.classList.add('dragging'); });
  for (const type of ['dragleave', 'drop']) zone.addEventListener(type, (e) => { e.preventDefault(); zone.classList.remove('dragging'); });
  zone.addEventListener('drop', (e) => addPhotos([...e.dataTransfer.files]));
  window.addEventListener('dragover', (e) => e.preventDefault());
  window.addEventListener('drop', (e) => e.preventDefault());
  for (const selector of ['#list-search', '#country-filter', '#tag-filter', '#sort']) $(selector).addEventListener('input', updateList);
  document.querySelectorAll('[data-collection-filter]').forEach((button) => {
    button.onclick = () => {
      document.querySelectorAll('[data-collection-filter]').forEach((item) => item.setAttribute('aria-pressed', String(item === button)));
      updateList();
    };
  });
  $('#clear-filters').onclick = () => { clearFilters(); updateList(); $('#list-search').focus(); };
  $('#route-toggle').onchange = (e) => mapController.route(e.target.checked);
  $('#map-style').value = mapController.getStyle();
  $('#map-style').onchange = (e) => mapController.setStyle(e.target.value);
  $('#heat-mode').value = mapController.getHeatMode();
  $('#heat-mode').onchange = (e) => mapController.setHeatMode(e.target.value);
  $('#show-markers').checked = mapController.markersVisible();
  $('#route-toggle').disabled = !mapController.markersVisible();
  $('#show-markers').onchange = (e) => { mapController.setMarkersVisible(e.target.checked); $('#route-toggle').disabled = !e.target.checked; };
  $('#fit-button').onclick = () => mapController.fit(destinations);
  $('#clear-examples').onclick = async () => {
    if (!await confirmAction('Limpar os exemplos?', 'Somente os exemplos que você ainda não editou serão removidos. Suas memórias serão preservadas.', 'Limpar exemplos')) return;
    try { await removeDestinations(destinations.filter((d) => d.example).map((d) => d.id)); await refresh(); notify('Exemplos removidos. O próximo destino é seu.'); }
    catch (error) { notify(storageMessage(error), true); }
  };
  $('#export-button').onclick = async () => {
    const button = $('#export-button'), label = button.innerHTML; button.disabled = true;
    try {
      notify('Preparando backup completo. Mídias que faltam neste dispositivo serão baixadas…');
      const backup = await exportBackup((done, total) => { button.textContent = `Backup ${done}/${total}`; });
      const url = URL.createObjectURL(new Blob([JSON.stringify(backup)], { type: 'application/json' }));
      const link = document.createElement('a'); link.href = url; link.download = `atlas-pessoal-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.append(link); link.click(); link.remove(); setTimeout(() => URL.revokeObjectURL(url), 60000);
      notify('Backup exportado com todos os destinos e fotografias.');
    } catch (error) { notify(storageMessage(error), true); }
    finally { button.disabled = false; button.innerHTML = label; }
  };
  $('#download-media-button').onclick = async () => {
    const token = ++offlineToken, button = $('#download-media-button'), status = $('#offline-media-status');
    offlineActive = token;
    button.disabled = true; $('#cancel-media-download').hidden = false;
    status.textContent = 'Preparando suas mídias para uso offline…';
    try {
      const result = await downloadOffline(await getAllPhotos(), { valid: () => token === offlineToken && !changingAccount && !publicView,
        onProgress: (done, total, failed) => { if (token === offlineToken) status.textContent = `Mídias verificadas: ${done}/${total}${failed ? ` · ${failed} para tentar novamente` : ''}.`; } });
      if (token !== offlineToken) return;
      if (result.cancelled) { status.textContent = 'Download interrompido. As mídias já baixadas foram preservadas.'; return; }
      status.textContent = result.failed ? `${result.failed} ${result.failed === 1 ? 'mídia não pôde ser baixada' : 'mídias não puderam ser baixadas'}. As demais estão salvas; tente novamente para completar.` : 'Suas mídias estão disponíveis neste dispositivo para uso offline.';
      await refresh();
    } catch (error) { if (token === offlineToken) status.textContent = storageMessage(error); }
    finally { if (offlineActive === token) { offlineActive = 0; button.disabled = false; $('#cancel-media-download').hidden = true; } }
  };
  $('#cancel-media-download').onclick = () => { offlineToken++; offlineActive = 0; cancelMediaDownloads(); $('#download-media-button').disabled = changingAccount || initializing; $('#cancel-media-download').hidden = true; $('#offline-media-status').textContent = 'Download interrompido. As mídias já baixadas foram preservadas.'; };
  $('#import-button').onclick = () => $('#import-input').click();
  $('#import-input').onchange = async (e) => {
    const file = e.target.files[0]; if (!file) return;
    $('#import-button').disabled = true;
    try { notify('Validando o backup e preparando as fotos…'); const count = await importBackup(file); await refresh(); social?.afterMutation(); notify(`${count} ${count === 1 ? 'destino importado' : 'destinos importados'}. Os registros existentes foram atualizados sem duplicação.`); }
    catch (error) { notify(storageMessage(error), true); }
    finally { e.target.value = ''; $('#import-button').disabled = false; }
  };
  window.addEventListener('resize', () => mapController.resize());
  window.addEventListener('pagehide', (event) => { if (!event.persisted) { for (const url of urls.values()) URL.revokeObjectURL(url); releaseEditorURLs(); } });
}
function setViewUI() {
  resetMediaView();
  mapFocus?.exit(); poster?.reset();
  document.body.classList.toggle('viewing-profile', Boolean(publicView));
  for (const selector of ['#add-button', '#export-button', '#import-button', '#wishlist-button', '#poster-button']) $(selector).hidden = Boolean(publicView);
  $('#public-profile-header').hidden = !publicView;
  $('.sidebar-heading .eyebrow').textContent = publicView ? 'VIAGENS PÚBLICAS' : 'SUA COLEÇÃO';
  $('.sidebar-heading h2').firstChild.textContent = publicView ? 'Viagens públicas ' : 'Meus destinos ';
  $('#detail-panel').hidden = true; $('#list-panel').hidden = false;
  clearFilters();
  if (publicView) {
    const p = publicView.profile;
    $('#public-profile-header').innerHTML = `<span id="public-avatar" class="profile-avatar" aria-hidden="true">${escapeHTML(p.display_name.slice(0, 1))}</span><div><p class="eyebrow">@${escapeHTML(p.username)}</p><h2>${escapeHTML(p.display_name)}</h2><p>${escapeHTML(p.bio || 'Um mapa de caminhos e memórias.')}</p></div><span class="tag">Perfil público</span>${publicView.publishedTrips?.length ? `<section class="profile-trips" aria-label="Trips publicadas"><h3>Trips compartilhadas</h3><div>${publicView.publishedTrips.map(t=>`<a class="trip-card" href="#/roteiro/${escapeHTML(t.id)}"><strong>${escapeHTML(t.name)}</strong><small>${t.stops.length} destinos · Ver roteiro</small></a>`).join('')}</div></section>` : ''}${publicWishlistHTML(publicView.wishlist)}`;
  } else {
    $('#public-profile-header').replaceChildren();
  }
  mapController.resize();
}
async function init() {
  setAccountLoading(true);
  try {
    const countries = await loadCountries();
    await openDatabase();
    mapController = createMap(countries, selectDestination, (coords) => openEditor(null, coords), () => {
      $('#map-status').textContent = 'Tiles indisponíveis. Seus países e destinos continuam acessíveis.';
    }, {
      photos: id => photosFor(destinations.find(d => d.id === id)),
      gallery: (id, index) => { const destination = destinations.find(d => d.id === id); if (destination) openGallery(photosFor(destination), index); },
      previews: observePreviews,
    });
    await refresh(); bindEvents();
    mapFocus = initializeMapFocus(mapController);
    journeys = initializeJourneys({ countries, destinations: () => destinations, preview: (stops) => { mapController.itinerary(stops); $('#route-toggle').checked = false; notify('Roteiro no mapa. As linhas unem paradas; não representam estradas.'); } });
    recaps = initializeRecaps(() => destinations);
    wishlist = initializeWishlist({ available: () => !changingAccount, afterMutation: () => social?.afterMutation(), diagnostic: () => social?.diagnostic(), reconnect: () => social?.reconnect() });
    poster = initializePoster({ countries, destinations: () => destinations, available: () => !initializing && !changingAccount && !publicView });
    social = await initializeSocial({
      refresh,
      refreshWishlist: () => wishlist.refresh(),
      lock: setAccountLoading,
      async switchAccount(id) {
        resetMediaView(); $('#offline-media-status').textContent = ''; $('#cancel-media-download').hidden = true;
        mapFocus.exit(); poster.reset();
        setAccountLoading(true); editorToken++; editor.close(); $('#gallery-dialog').close(); publicView = null; selectedId = null;
        journeys.reset(); recaps.reset(); wishlist.reset();
        $('#destination-form').reset(); $('#visits-editor').replaceChildren(); $('#photo-editor').replaceChildren();
        editPhotos = []; coverId = null; releaseEditorURLs();
        try { await openDatabase({ accountId: id }); setViewUI(); await refresh(); }
        finally { setAccountLoading(false); }
      },
      async showOwn({ preserveSelection = false } = {}) { if(preserveSelection && !publicView){await refresh();return;} publicView = null; selectedId = null; setViewUI(); await refresh(); },
      async showPublic(data) { publicView = data; selectedId = null; setViewUI(); await refresh(); mapController.fit(destinations); },
      showTrip: () => journeys.route(),
    });
    await journeys.route();
    initializing = false; setAccountLoading(false);
  } catch (error) {
    notify(storageMessage(error), true);
    $('#destination-list').innerHTML = `<div class="empty-state"><h3>Não foi possível abrir o atlas</h3><p>${escapeHTML(storageMessage(error))}</p><button class="primary" id="retry-init">Tentar novamente</button></div>`;
    $('#retry-init').onclick = () => location.reload();
  }
}
init();
