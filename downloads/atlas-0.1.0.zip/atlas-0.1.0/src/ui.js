import { mediaLabel, mediaKind } from './media.js';
import { totalDays, durationLabel, displayDate, visitedDestinations } from './dates.js';
export const $ = (selector, root = document) => root.querySelector(selector);
export const escapeHTML = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let toastTimer;
export function notify(message, error = false) {
  const toast = $('#toast');
  clearTimeout(toastTimer);
  toast.textContent = message;
  toast.classList.toggle('error', error);
  toast.setAttribute('role', error ? 'alert' : 'status');
  toast.hidden = false;
  toastTimer = setTimeout(() => { toast.hidden = true; }, error ? 10000 : 5500);
}
export function confirmAction(title, message, action = 'Excluir') {
  const dialog = $('#confirm-dialog');
  $('#confirm-title').textContent = title;
  $('#confirm-message').textContent = message;
  $('#confirm-ok').textContent = action;
  dialog.returnValue = '';
  $('#confirm-ok').onclick = () => dialog.close('yes');
  $('#confirm-cancel').onclick = () => dialog.close('no');
  return new Promise((resolve) => {
    dialog.addEventListener('close', () => resolve(dialog.returnValue === 'yes'), { once: true });
    dialog.showModal();
  });
}
export function renderFilterOptions(destinations) {
  for (const [selector, values, label] of [
    ['#country-filter', [...new Set(destinations.map((d) => d.countryName))], 'Todos os países'],
    ['#tag-filter', [...new Set(destinations.flatMap((d) => d.tags))], 'Todas as etiquetas'],
  ]) {
    const select = $(selector), previous = select.value;
    select.innerHTML = `<option value="">${label}</option>${values.sort((a, b) => a.localeCompare(b, 'pt-BR')).map((v) => `<option value="${escapeHTML(v)}">${escapeHTML(v)}</option>`).join('')}`;
    if (values.includes(previous)) select.value = previous;
  }
}
export function renderList(destinations, urls, onSelect, onAdd, readOnly = false) {
  const normalizeSearch = (value) => String(value).normalize('NFD').replace(/\p{M}/gu, '').toLocaleLowerCase('pt-BR');
  const query = normalizeSearch($('#list-search').value.trim());
  const country = $('#country-filter').value, tag = $('#tag-filter').value;
  const collection = $('[data-collection-filter][aria-pressed="true"]').dataset.collectionFilter;
  const candidates = collection === 'visited' ? visitedDestinations(destinations) : collection === 'favorites' ? destinations.filter((d) => d.favorite) : destinations;
  const visible = candidates.filter((d) => (!country || d.countryName === country) && (!tag || d.tags.includes(tag)) && [d.name, d.countryName, d.notes, ...d.tags].some((value) => normalizeSearch(value).includes(query)));
  const sort = $('#sort').value;
  const latest = (d) => d.visits.map((v) => v.arrival).filter(Boolean).sort().at(-1) || '';
  visible.sort((a, b) => Number(Boolean(b.pinned)) - Number(Boolean(a.pinned)) || (sort === 'name' ? a.name.localeCompare(b.name, 'pt-BR') : sort === 'duration' ? totalDays(b) - totalDays(a) : sort === 'rating' ? b.rating - a.rating : latest(b).localeCompare(latest(a))) || a.name.localeCompare(b.name, 'pt-BR'));
  const filtered = Boolean(query || country || tag || collection !== 'all');
  $('#destination-count').textContent = filtered ? `${visible.length} / ${destinations.length}` : destinations.length;
  $('#destination-count').setAttribute('aria-label', `${visible.length} de ${destinations.length} destinos`);
  $('#clear-filters').hidden = !filtered;
  $('#examples-banner').hidden = !destinations.some((d) => d.example);
  const list = $('#destination-list');
  if (!visible.length) {
    list.innerHTML = `<div class="empty-state"><div class="empty-icon" aria-hidden="true">◇</div><h3>${destinations.length ? 'Nenhuma memória por aqui' : 'O mundo está à sua espera'}</h3><p>${destinations.length ? 'Experimente outra busca ou ajuste os filtros.' : 'Comece por um lugar que ficou com você.<br>Clique no mapa ou adicione seu primeiro destino.'}</p>${destinations.length ? '' : '<button class="primary" id="empty-add">Adicionar destino</button>'}</div>`;
    $('#empty-add')?.addEventListener('click', onAdd);
    if (readOnly && !destinations.length) { $('#empty-add')?.remove(); $('.empty-state p', list).textContent = 'Este perfil ainda não tem viagens públicas.'; }
    return;
  }
  list.innerHTML = visible.map((d) => `<button class="destination-card" data-destination-id="${escapeHTML(d.id)}" aria-label="Abrir destino ${escapeHTML(d.name)}"><span class="destination-thumb" data-media-id="${escapeHTML(d.coverId || '')}">${urls.has(d.coverId) ? `<img src="${urls.get(d.coverId)}" alt="" loading="lazy">` : '◇'}</span><span class="destination-summary"><strong>${escapeHTML(d.name)}</strong><small>${escapeHTML(d.countryName)}${d.rating ? ` · ${'★'.repeat(d.rating)}` : ''}</small><span class="duration">${durationLabel(totalDays(d))} · ${d.visits.length} ${d.visits.length === 1 ? 'visita' : 'visitas'}</span></span><span class="card-chevron" aria-hidden="true">›</span></button>`).join('');
  list.querySelectorAll('[data-destination-id]').forEach((button) => button.addEventListener('click', () => onSelect(button.dataset.destinationId)));
  list.querySelectorAll('[data-destination-id]').forEach((button) => {
    const d = visible.find((item) => item.id === button.dataset.destinationId);
    if (d.kind === 'home') { const badge = document.createElement('small'); badge.className = 'home-badge'; badge.textContent = '⌂ Casa / moradia'; $('.destination-summary', button).append(badge); }
    if (d.pinned || d.favorite) { const badge = document.createElement('small'); badge.className = 'highlight-badge'; badge.textContent = [d.pinned && '📌 Fixada', d.favorite && '★ Favorita'].filter(Boolean).join(' · '); $('.destination-summary', button).append(badge); }
  });
}
export function renderDetail(destination, photos, urls, actions) {
  const d = destination;
  const panel = $('#detail-panel');
  $('#list-panel').hidden = true;
  panel.hidden = false;
  panel.innerHTML = `<header class="detail-header"><button class="text-button" data-back>← Meus destinos</button><span class="eyebrow">${d.example ? 'EXEMPLO' : 'MEMÓRIA'}</span></header><div class="detail-cover" data-media-id="${escapeHTML(d.coverId || '')}">${urls.has(d.coverId) ? `<img src="${urls.get(d.coverId)}" alt="Foto de capa de ${escapeHTML(d.name)}">` : '◇'}<span class="cover-count">${photos.length ? `${photos.length} ${photos.length === 1 ? 'mídia' : 'mídias'}` : 'A sua próxima fotografia'}</span></div><div class="detail-body"><h2>${escapeHTML(d.name)}</h2><p class="detail-subtitle">${escapeHTML(d.countryName)}${d.continent ? ` · ${escapeHTML(d.continent)}` : ''}</p><p class="detail-stars" aria-label="${d.rating ? `Avaliação: ${d.rating} de 5` : 'Sem avaliação'}">${d.rating ? '★'.repeat(d.rating) + '☆'.repeat(5 - d.rating) : ''}</p><div class="detail-tags">${d.tags.map((tag) => `<span class="tag">${escapeHTML(tag)}</span>`).join('')}</div><section class="detail-section"><h3>O tempo por aqui · ${durationLabel(totalDays(d))}</h3>${d.visits.length ? d.visits.map((v, index) => `<div class="visit-summary"><strong>Visita ${index + 1} · ${durationLabel(totalDays({ visits: [v] }))}</strong><small>${v.manualDays != null ? 'Duração informada manualmente' : `${displayDate(v.arrival)} — ${displayDate(v.departure)}`}</small></div>`).join('') : '<p>Nenhuma visita registrada.</p>'}</section><section class="detail-section"><h3>Notas de viagem</h3><p>${escapeHTML(d.notes || 'Uma página em branco, esperando pelas suas memórias.')}</p></section><section class="detail-section"><h3>Galeria · ${photos.length}</h3><div class="detail-gallery">${photos.map((photo, index) => `<button data-photo-index="${index}" data-media-id="${escapeHTML(photo.id)}" aria-label="${mediaKind(photo) === 'image' ? 'Abrir foto' : `Abrir ${mediaLabel(photo)}`} ${index + 1}${photo.caption ? `: ${escapeHTML(photo.caption)}` : ''}">${urls.has(photo.id) ? `<img src="${urls.get(photo.id)}" alt="${escapeHTML(photo.caption || `Fotografia de ${d.name}`)}" loading="lazy">` : '<span class="media-placeholder" aria-hidden="true">◇</span>'}${mediaKind(photo) !== 'image' ? `<span class="media-badge">▶ ${mediaLabel(photo)}</span>` : ''}</button>`).join('')}</div>${photos.length ? '' : '<p>As imagens também fazem parte da história.<br>Edite este destino para adicionar fotos, vídeos e Live Photos.</p>'}</section><div class="detail-actions"><button class="primary" data-edit>Editar destino</button><button class="quiet" data-delete>Excluir destino</button></div><p class="detail-coordinates">${d.lat.toFixed(5)}°, ${d.lng.toFixed(5)}°</p></div>`;
  $('[data-back]', panel).onclick = actions.back;
  $('[data-edit]', panel).onclick = actions.edit;
  $('[data-delete]', panel).onclick = actions.remove;
  if (actions.readOnly) $('.detail-actions', panel).remove();
  else if (actions.account) {
    const badge = document.createElement('p'); badge.className = 'field-hint';
    badge.textContent = d.visibility === 'public' ? 'Postagem pública no seu perfil.' : 'Postagem privada · somente você pode ver.';
    $('.detail-body', panel).prepend(badge);
  }
  panel.querySelectorAll('[data-photo-index]').forEach((button) => button.onclick = () => actions.gallery(Number(button.dataset.photoIndex)));
  const share = document.createElement('button'); share.className = 'quiet'; share.textContent = 'Compartilhar no WhatsApp'; share.onclick = actions.share; $('.detail-body', panel).append(share);
  if (d.favorite || d.pinned) { const badge = document.createElement('p'); badge.className = 'highlight-badge'; badge.textContent = [d.pinned && '📌 Fixada', d.favorite && '★ Favorita'].filter(Boolean).join(' · '); $('.detail-body', panel).prepend(badge); }
  if (d.kind === 'home') { const badge = document.createElement('p'); badge.className = 'home-badge'; badge.textContent = '⌂ Casa / moradia'; $('.detail-body', panel).prepend(badge); }
}
